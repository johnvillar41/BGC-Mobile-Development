package emp.project.softwareengineerproject.Interface;

public interface ILogin {
    interface ILoginView {
        void initViews();

        void onSuccess(String message);

        void onError(String message);

        void goToMainPage();
    }
    interface ILoginPresenter {
        void onLoginButtonClicked();
    }
    interface IDbHelper {
        void StrictMode();

        Boolean checkLoginCredentialsDB();
    }
}
