package emp.project.softwareengineerproject.Model;

public class LoginModel {
    String user_id, user_username, user_password;

    public LoginModel(String user_username, String user_password) {
        this.user_username = user_username;
        this.user_password = user_password;
    }

    public LoginModel() {
    }

    public String getUser_id() {
        return user_id;
    }

    public String getUser_username() {
        return user_username;
    }

    public String getUser_password() {
        return user_password;
    }

    public String validateCredentials(LoginModel model) {
        String message = null;
        if (model.getUser_username().length() == 0) {
            message = "Fill up username field!";
        } else if (model.getUser_password().length() == 0) {
            message = "Fill up password field!";
        } else if (model.getUser_username().length() == 0 && model.getUser_password().length() == 0) {
            message = "Fill up both fields!";
        }
        return message;
    }
}
