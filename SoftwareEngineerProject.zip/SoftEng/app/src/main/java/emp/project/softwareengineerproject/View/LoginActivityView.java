package emp.project.softwareengineerproject.View;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.Toast;

import emp.project.softwareengineerproject.Interface.ILogin;
import emp.project.softwareengineerproject.R;

public class LoginActivityView extends AppCompatActivity implements ILogin.ILoginView {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);
        initViews();
    }

    @Override
    public void initViews() {
        //initialize views here
    }

    @Override
    public void onSuccess(String message) {
        Toast.makeText(this,message,Toast.LENGTH_SHORT).show();
    }

    @Override
    public void onError(String message) {
        Toast.makeText(this,message,Toast.LENGTH_SHORT).show();
    }

    @Override
    public void goToMainPage() {
        //go to main page
    }
}